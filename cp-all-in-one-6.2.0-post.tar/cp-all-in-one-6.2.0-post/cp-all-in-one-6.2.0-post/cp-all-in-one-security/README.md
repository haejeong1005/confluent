![image](../images/confluent-logo-300-2.png)
  
# Documentation

Securing your Apache Kafka cluster can involve various security features.
For an example that shows security features in action, see [cp-demo](https://docs.confluent.io/platform/current/tutorials/cp-demo/docs/index.html?utm_source=github&utm_medium=demo&utm_campaign=ch.examples_type.community_content.cp-all-in-one).
Refer to cp-demo's [docker-compose.yml](https://github.com/confluentinc/cp-demo/blob/6.2.0-post/docker-compose.yml) for a configuration reference.
